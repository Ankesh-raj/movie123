﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BookShowDAL.Migrations
{
    public partial class booktheshowuser12 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
